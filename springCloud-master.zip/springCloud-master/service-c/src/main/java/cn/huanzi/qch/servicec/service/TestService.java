package cn.huanzi.qch.servicec.service;


import cn.huanzi.qch.servicec.pojo.TbDescription;

public interface TestService {
    public TbDescription txlcn(Integer userId);
}
