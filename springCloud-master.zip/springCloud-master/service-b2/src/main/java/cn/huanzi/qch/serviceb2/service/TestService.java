package cn.huanzi.qch.serviceb2.service;


import cn.huanzi.qch.serviceb2.pojo.TbDescription;

public interface TestService {
    public TbDescription txlcn(Integer userId);
}
