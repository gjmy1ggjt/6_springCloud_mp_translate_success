package cn.huanzi.qch.servicea.service;

public interface TestService {
    public String txlcn(String exFlag);
}
