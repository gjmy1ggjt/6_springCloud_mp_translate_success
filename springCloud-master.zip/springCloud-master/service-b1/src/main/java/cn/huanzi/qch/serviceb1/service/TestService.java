package cn.huanzi.qch.serviceb1.service;

import cn.huanzi.qch.serviceb1.pojo.TbDescription;

public interface TestService {
    public TbDescription txlcn(Integer userId);
}
